package com.viraj.eh.Model;

import javax.validation.constraints.Size;

public class Event {

	@Size(min=4,max=15, message="Event name should be 4 and 15")
	String eventName;

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	
}
