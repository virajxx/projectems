package com.viraj.eh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.viraj.eh.Model.Activity;

@Controller
public class ActivityController {
	
	@RequestMapping(value="/greeting")
	public String getWelcomeMessage(Model model)
	{
		model.addAttribute("msg", "Hi spring you are awesome");
		return "Welcome";
	}
	
	@RequestMapping("/addactivity")
	public String addActivity(@ModelAttribute("activities")Activity activity)
	{
		System.out.println(activity.getActivityName());
		if(activity.getActivityName()== null)
		{
			return "addactivity";
		}
		return "redirect:addSubActivity.html";
	}
	
	@RequestMapping("/addSubActivity")
	public String addSubActivity(@ModelAttribute("activities")Activity activity)
	{
		System.out.println("Sub activity is :"+activity.getActivityName());
		return "addactivity";
	}
	
	
	

}
